import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        return (
            <h2 className="text-info">Hello from Component One</h2>
        );
    }
}

export default ComponentOne;