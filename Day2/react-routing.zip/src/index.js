import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { BrowserRouter } from 'react-router-dom';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<BrowserRouter>
    <RootComponent />
</BrowserRouter>, document.getElementById('root'));

// var employeee = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// var id = employeee.id;
// var name = employeee.name;

// var { id, name, ...address } = employeee;  // Object Rest

// console.log(id);
// console.log(name);
// console.log(address);

// var e1 = employeee;
// var e1 = Object.assign({}, employeee);
// var e1 = {...employeee};        // Object Spread - ES 2018

// e1.id = 1000;

// console.log("e1 ", e1);
// console.log("emp ", employeee);

// ... on Left Hand side of EqualTo Operator = Rest
// ... on Right Hand side of EqualTo Operator = Spread

// ... in Function Creation = Rest
// ... in Function Call = Spread
