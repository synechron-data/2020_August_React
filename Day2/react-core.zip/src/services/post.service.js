const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIClient = {
    getAllPosts: function () {
        return new Promise((resolve, reject) => {
            fetch(url).then(response => {
                response.json().then(data => {
                    setTimeout(() => {
                        resolve(data);
                    }, 5000);
                }).catch(err => {
                    reject("Parsing Error...");
                })
            }).catch(err => {
                reject("Communication Error...");
            })
        });
    }
};

export default postAPIClient;