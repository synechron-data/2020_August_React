import React, { Component } from 'react';
import postAPIClient from '../../services/post.service';
import DataTable from '../common/DataTable';

// const obj = React.createContext();
// console.log(obj);

const { Provider, Consumer } = React.createContext();

class ChildComponentOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildComponentTwo />
            </div>
        );
    }
}

class ChildComponentTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
            </div>
        );
    }
}

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait...." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-info">Main Component</h3>
                </div>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <Provider value={this.state.posts}>
                    <ChildComponentOne />
                </Provider>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then(data => {
            this.setState({ posts: [...data], message: "" });
        }).catch(eMsg => {
            this.setState({ posts: [], message: eMsg });
        });
    }
}

export default ContextAPIDemo;

// ---------------------------------------------------------- Prop Drilling or Prop Forwarding
// import React, { Component } from 'react';
// import postAPIClient from '../../services/post.service';
// import DataTable from '../common/DataTable';

// class ChildComponentOne extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child One</h3>
//                 <ChildComponentTwo data={this.props.data} />
//             </div>
//         );
//     }
// }

// class ChildComponentTwo extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child Two</h3>
//                 <DataTable items={this.props.data}>
//                     <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
//                 </DataTable>
//             </div>
//         );
//     }
// }

// class ContextAPIDemo extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { posts: [], message: "Loading Data, please wait...." };
//     }

//     render() {
//         return (
//             <React.Fragment>
//                 <div className="row">
//                     <h3 className="text-info">Main Component</h3>
//                 </div>
//                 <div className="row">
//                     <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
//                 </div>
//                 <ChildComponentOne data={this.state.posts} />
//             </React.Fragment>
//         );
//     }

//     componentDidMount() {
//         postAPIClient.getAllPosts().then(data => {
//             this.setState({ posts: [...data], message: "" });
//         }).catch(eMsg => {
//             this.setState({ posts: [], message: eMsg });
//         });
//     }
// }

// export default ContextAPIDemo;