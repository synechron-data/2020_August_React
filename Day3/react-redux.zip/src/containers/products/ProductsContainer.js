import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';
import LoaderAnimation from '../../components/common/LoaderAnimation';
import ProductListComponent from '../../components/products/ProductListComponent';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    render() {
        return (
            <React.Fragment>
                {
                    this.props.flag ?
                        <React.Fragment>
                            <br />
                            <br />
                            <AddProductButton />
                            <br />
                            <br />
                            <ProductListComponent products={this.props.products} onDelete={this.deleteProduct} />
                        </React.Fragment>
                        :
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div>
                }
            </React.Fragment>
        );
    }

    deleteProduct(p, e) {
        this.props.deleteProduct(p);
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products,
        status: state.productReducer.status,
        flag: state.productReducer.flag
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); },
        deleteProduct: (p) => { dispatch(productActions.deleteProduct(p)); }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);