import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { message: msg, flag: false }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { data: products, message: msg, flag: true }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { message: msg, flag: true }
    };
}

// A thunk is a function that returns another function which takes dispatch as a parameter
export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Products Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Products Request Completed Successfully..."));
            }, 5000);
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

function insertProductSuccess(product, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedproduct) => {
            dispatch(insertProductSuccess(insertedproduct, "Record Inserted Successfully..."));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

function updateProductSuccess(product, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedproduct) => {
            dispatch(updateProductSuccess(updatedproduct, "Record Updated Successfully..."));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

function deleteProductSuccess(product, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductSuccess(product, "Record Deleted Successfully..."));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}