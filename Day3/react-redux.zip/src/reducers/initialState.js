export default {
    count: 0,
    productsData: { products: [], status: "", flag: false }
}